package com.example.compose1.ui.theme

import androidx.compose.ui.graphics.Color

val purple = Color(0xFF4C00FF)
val orangeRed = Color(0xFFFD543E)
val blue = Color(0xFF3686FF)
val lightPurple = Color(0xFF9568FF)

val black = Color(0xFF000000)
val white = Color(0xFFFFFFFF)