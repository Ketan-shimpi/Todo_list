package com.example.compose1.dataClasses

class UserData(val email: String, val password: String) {

}